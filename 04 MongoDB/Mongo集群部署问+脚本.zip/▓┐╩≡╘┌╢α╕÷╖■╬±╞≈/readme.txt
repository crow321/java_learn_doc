共4个脚本，分别为
	Shard节点初始化脚本
	Shard节点启动脚本
	Monogs集群初始化脚本
	mongos集群启动脚本