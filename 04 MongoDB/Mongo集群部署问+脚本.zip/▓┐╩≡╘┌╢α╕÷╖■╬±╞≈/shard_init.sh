#!/bin/bash
#
###############################################################################################
#	Configuration:
#		1.只需配置默认端口  default_port 如 20000
#			Config Node 1 port: 22005
#			Shard Node 1 port :	22001
#			Shard Node 2 port :	22002
#			Shard Node 3 port :	22003
###############################################################################################
#
Check_Port()
{
    if [ $1 -lt 20000 -o $1 -ge 65535 ];then
	    echo "Invalid Port: Please set port is between 20000 and 65535!"
		exit 1;
	fi
}
#set config port
read -p "Please enter the default port : " default_port
Check_Port $default_port;
echo "Set the default port is $default_port"
#
###############################################################################################
ip=`ifconfig eth0 |grep "inet addr"| cut -f 2 -d ":"|cut -f 1 -d " " `
shardReplSetName=shardReplSet-$ip
cfgReplSetName=cfgReplSet

echo "localhost ip is $ip"
#set shard port
shard_1_port=$[ default_port+1 ]
shard_2_port=$[ default_port+2 ]
shard_3_port=$[ default_port+3 ]
#set config port
config_port=$[ default_port+5 ]

mkdir -p /home/mongodb/config/data
mkdir -p /home/mongodb/config/log
cd /home/mongodb/

for j in 1 2 3
    do
    mkdir -p /home/mongodb/shard$j/data
    mkdir -p /home/mongodb/shard$j/log
	
    #start shard
	shard_port=$[ default_port+j ]
	shard_name=shard$j
    mongod --shardsvr --replSet $shardReplSetName --port $shard_port --dbpath /home/mongodb/$shard_name/data --logpath /home/mongodb/$shard_name/log/$shard_name.log --fork
done
echo "------------------- start shard replSet complete -------------------"

# set shardReplSet
mongo $ip:$shard_1_port <<EOF
use admin

config = {_id: '$shardReplSetName', members: [
                          {_id: 0, host: '$ip:$shard_1_port'},
                          {_id: 1, host: '$ip:$shard_2_port'},
                          {_id: 2, host: '$ip:$shard_3_port',"arbiterOnly":true}
             ]
        }

# 初始化配置
rs.initiate(config);

db.getMongo().setSlaveOk()

exit
EOF

#start config
mongod --configsvr --replSet $cfgReplSetName --port $config_port --dbpath /home/mongodb/config/data --logpath /home/mongodb/config/log/config.log --fork

ps -ef|grep mongo
