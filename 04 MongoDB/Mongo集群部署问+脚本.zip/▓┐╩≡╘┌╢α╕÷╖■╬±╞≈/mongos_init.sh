#!/bin/bash
#
###############################################################################################
#	Configuration:
#		1.配置Shard ReplSet Node IP
#			server_1_ip、server_2_ip、server_3_ip	
#		2.配置默认端口（必须与shard_init.sh脚本中保持一致）	default_port
#		3.Mongos 路由节点端口为 default_port+5
#		连接mongo集群时将客户端指向 Mongos 即可，默认Mongos 地址: localhost:22005
###############################################################################################
#
Check_IP() 
{
    ip=$1
    while true
    do
	    #输入不能为空
		if [ -z $ip ];then		
		    echo "Enter not null."
			exit 1;
		#如果输入exit、quit、q就退出输入模式
		elif [ $ip == exit -o $ip == quit -o $ip == q ];then
		    echo "Enter exit|quit|q and finish!"
            exit 1;
	    #输入的不是数字或不是IP格式，则重新输入
		elif [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]];then
            #^$：从开始到结束是数字才满足条件,=~：一个操作符，表示左边是否满足右边（作为一个模式）正则表达式
            a=`echo $ip |cut -d. -f1`
			b=`echo $ip |cut -d. -f2`
			c=`echo $ip |cut -d. -f3`
			d=`echo $ip |cut -d. -f4`
            if [ $a -le 255 -a $a -gt 0 -a $b -le 255 -a $c -le 255 -a $d -le 255 -a $d -gt 0 ];then
			#当满足输入条件时，截取IP四段数字进行整数比较，判断四段数字是否小于或等于255，同时满足条件，跳出所有循环继续，如果其中一个不满足，则重新输入
			#IP首段数字和最后一个数字不能为0
			    break;
            else
                echo "IP value range error,Please enter the IP again."
				exit 1;
            fi
        else
            echo "IP format error,Please enter the IP again."
			exit 1;
        fi
    done	
}

Check_Port()
{
    if [ $1 -lt 20000 -o $1 -ge 65535 ];then
	    echo "Invalid Port: Please set port is between 20000 and 65535!"
		exit 1;
	fi
}

#set mongo shards ip
read -p "Please enter the first ShardReplSet IP address: " server_1_ip
Check_IP $server_1_ip;
echo "Set the first ShardReplSet IP address 1is $server_1_ip"

read -p "Please enter the second ShardReplSet IP address: " server_2_ip
Check_IP $server_2_ip;
echo "Set the second ShardReplSet IP address is $server_2_ip"

read -p "Please enter the third ShardReplSet IP address: " server_3_ip
Check_IP $server_3_ip;
echo "Set the third ShardReplSet IP address is $server_3_ip"

#set config port
echo "Please make sure the port is same as the shardReplSet port!"
read -p "Please enter the default port : " default_port
Check_Port $default_port;
echo "Set the default port is $default_port"

##################################################################################
#
##################################################################################
#set mongos port
mongos_port=$default_port
#set config port
config_port=$[ default_port+5 ]
#set shard port
shard_1_port=$[ default_port+1 ]

#set shardReplSet name
shardReplSetName_1=shardReplSet-$server_1_ip
shardReplSetName_2=shardReplSet-$server_2_ip
shardReplSetName_3=shardReplSet-$server_3_ip

#set configReplSet name
cfgReplSetName=cfgReplSet

# 4.mongos节点配置
mkdir -p /home/mongodb/mongos/data
mkdir -p /home/mongodb/mongos/log

#配置config server复制集
mongo $server_1_ip:$config_port <<EOF
use admin

config = {_id: '$cfgReplSetName',
                      members: [
                      {   _id: 0, host: '$server_1_ip:$config_port'},
                      {   _id: 1, host: '$server_2_ip:$config_port'},
                      {   _id: 2, host: '$server_3_ip:$config_port'}
                  ]
          }

# 初始化配置
rs.initiate(config);

rs.status()

exit
EOF


mongos --configdb $cfgReplSetName/$server_1_ip:$config_port,$server_2_ip:$config_port,$server_3_ip:$config_port --port $mongos_port --logpath /home/mongodb/mongos/log/mongos.log --fork

mongo localhost:$mongos_port <<EOF
use admin

db.runCommand( { addshard : "$shardReplSetName_1/$server_1_ip:$shard_1_port",name:"$shardReplSetName_1"} )

db.runCommand( { addshard : "$shardReplSetName_2/$server_2_ip:$shard_1_port",name:"$shardReplSetName_2"} )

db.runCommand( { addshard : "$shardReplSetName_3/$server_3_ip:$shard_1_port",name:"$shardReplSetName_3"} )



exit
EOF


# 添加数据库 打开分片功能
#增加集合
#添加索引
mongo localhost:$mongos_port <<EOF
use key_store

sh.enableSharding("key_store")

sh.shardCollection("key_store.statistics_info", {_id:"hashed"})
sh.shardCollection("key_store.service_key", {_id:"hashed"})
sh.shardCollection("key_store.quantum_key", {_id:"hashed"})
sh.shardCollection("key_store.random_digit", {_id:"hashed"})
sh.shardCollection("key_store.application_key", {_id:"hashed"})
sh.shardCollection("key_store.quantum_application_key", {_id:"hashed"})
sh.shardCollection("key_store.node_status", {_id:"hashed"})

db.node_status.ensureIndex({"userID":1,"createTime":-1})
db.quantum_key.ensureIndex({"nodeID":1,"keyState":1,"createTime":1})
db.application_key.ensureIndex({"owner":1,"createTime":1})
db.application_key.ensureIndex({"sessionID":1,"createTime":1})
db.application_key.ensureIndex({"sessionID":1})

sh.status();

exit
EOF

ps -ef|grep mongo