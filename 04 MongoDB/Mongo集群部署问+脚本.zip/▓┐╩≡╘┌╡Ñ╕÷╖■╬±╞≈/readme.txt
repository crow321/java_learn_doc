1.第一次启动mongo时，请使用mongo初始化脚本:
	mongos_init.sh
2.如果已经初始化mongo，请使用mongo启动脚本:
	mongos_startup.sh
