package cn.qtec.qkcl.service;

import cn.qtec.qkcl.entity.QuantumKey;

import java.util.List;

/**
 * @author Created by zhangp on 2018/5/10
 */
public interface KeyQueryService {
    List <QuantumKey> findAllByNodeIdByCreateTime();

    List <QuantumKey> findAllByNodeIdByCreateTime(long nodeId);

    List <QuantumKey> findAllByNodeIdOrderByKeyId(long nodeId);

}
