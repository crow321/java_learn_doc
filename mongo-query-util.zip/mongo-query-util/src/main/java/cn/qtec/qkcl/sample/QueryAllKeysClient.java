package cn.qtec.qkcl.sample;

import cn.qtec.qkcl.service.KeyQueryService;
import cn.qtec.qkcl.service.impl.KeyQueryServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Created by zhangp on 2018/5/10
 */
public class QueryAllKeysClient {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring-context.xml");
        KeyQueryService service = context.getBean(KeyQueryServiceImpl.class);
        service.findAllByNodeIdByCreateTime();
    }
}
