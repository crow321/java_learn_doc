package cn.qtec.qkcl.security.impl;

import cn.qtec.qkcl.security.ISecurity;
import com.sansec.jce.provider.SwxaProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.security.Security;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 *
 * @author Created by INM on 2017/4/24
 */
@Component
public class SecurityImpl implements ISecurity {
    private static final Logger logger = LoggerFactory.getLogger(SecurityImpl.class);

    private static final String AES = "AES/CBC/PKCS7PADDING";
    private static final String SM4 = "SM4/CBC/PKCS5PADDING";
    private static final String SM1 = "SM1/CBC/PKCS5PADDING";
    private static final String SSF33 = "SSF33/CBC/PKCS5PADDING";
    private static final String secretKey = "for-freedom-lifefor-freedom-life";
    @Value("${secret.algorithm}")
    private String secretAlgorithm;
    @Value(("${cipherNumber}"))
    private int cipherNumber;
    @Value("${use.internal.key}")
    private boolean useInternalKey;
    @Value(("${internal.key.index}"))
    private int internalKeyIndex;
    private ThreadLocal<Cipher> encThreadLocal = new ThreadLocal<>();
    private ThreadLocal<Cipher> decThreadLocal = new ThreadLocal<>();
    private ConcurrentLinkedQueue<Cipher> encCipherStack = new ConcurrentLinkedQueue<>();
    private ConcurrentLinkedQueue<Cipher> decCipherStack = new ConcurrentLinkedQueue<>();
    /* iv向量，16位0 */
    private byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    private Key key;

    @PostConstruct
    public void init() throws Exception {
        logger.info("Start init Cipher");
        secretAlgorithm.toUpperCase();
        logger.info("EncryptAlgorithm is {}", secretAlgorithm);
        if (secretAlgorithm.startsWith("SM4")) {
            instanceCipher("SM4", SM4);
        } else if (secretAlgorithm.startsWith("SM1")) {
            instanceCipher("SM1", SM1);
        } else if (secretAlgorithm.startsWith("SSF33")) {
            instanceCipher("SSF33", SSF33);
        } else {
            instanceCipher("AES", AES);
        }
        logger.info("Cipher init success!");
    }

    private void instanceCipher(String algo, final String s) throws Exception {
        if (algo.equals("AES")) {
            logger.info("Load default JCE");
            Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
            key = new SecretKeySpec(secretKey.getBytes(), algo);
            for (int i = 0; i < cipherNumber; i++) {
                Cipher cipher = Cipher.getInstance(s);
                cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
                encCipherStack.add(cipher);

                Cipher cipher2 = Cipher.getInstance(s);
                cipher2.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
                decCipherStack.add(cipher2);
            }
        } else {
            logger.info("Load SwxaJCE");
            Security.addProvider(new SwxaProvider());
            if (useInternalKey) {
                KeyGenerator kg = KeyGenerator.getInstance(algo, "SwxaJCE");
                kg.init(internalKeyIndex << 16);
                key = kg.generateKey();
                if (key == null) {
                    logger.error("GetInternal Key Error");
                    throw new NullPointerException();
                } else {
                    logger.info("GetInternal Key Success!");
                }
            } else {
                key = new SecretKeySpec(secretKey.getBytes(), algo);
            }
            for (int i = 0; i < cipherNumber; i++) {
                Cipher cipher = Cipher.getInstance(s, "SwxaJCE");
                cipher.init(Cipher.ENCRYPT_MODE, key);
                encCipherStack.add(cipher);

                Cipher cipher2 = Cipher.getInstance(s, "SwxaJCE");
                cipher2.init(Cipher.DECRYPT_MODE, key);
                decCipherStack.add(cipher2);
            }
        }
    }

    private Cipher getCipher(final String algo, int mode) throws Exception {
        Cipher cipher;
        if (algo.startsWith("SM4")) {
            cipher = Cipher.getInstance(SM4, "SwxaJCE");
            cipher.init(mode, key);
        } else if (algo.startsWith("SM1")) {
            cipher = Cipher.getInstance(SM1, "SwxaJCE");
            cipher.init(mode, key);
        } else if (algo.startsWith("SSF33")) {
            cipher = Cipher.getInstance(SSF33, "SwxaJCE");
            cipher.init(mode, key);
        } else {
            cipher = Cipher.getInstance(AES);
            cipher.init(mode, key, new IvParameterSpec(iv));
        }
        return cipher;
    }

    public byte[] encryption(byte[] bytes) throws Exception {
        Cipher cipher = getEncCipher();
        byte[] encData = cipher.doFinal(bytes);
        return encData;
    }

    public byte[] decryption(byte[] bytes) throws Exception {
        Cipher cipher = getDecCipher();
        byte[] encData = cipher.doFinal(bytes);
        return encData;
    }

    @Override
    public byte[] encryption(byte[] bytes, byte[] key) throws Exception {
        return null;
    }

    @Override
    public byte[] decryption(byte[] bytes, byte[] key) throws Exception {
        return null;
    }

    private Cipher getEncCipher() throws Exception {
        Cipher cipher = encThreadLocal.get();
        if (cipher == null) {
            cipher = encCipherStack.poll();
            if (cipher == null) {
                cipher = getCipher(secretAlgorithm, Cipher.ENCRYPT_MODE);
            }
            encThreadLocal.set(cipher);
        }
        return cipher;
    }

    private Cipher getDecCipher() throws Exception {
        Cipher cipher = decThreadLocal.get();
        if (cipher == null) {
            cipher = decCipherStack.poll();
            if (cipher == null) {
                cipher = getCipher(secretAlgorithm, Cipher.DECRYPT_MODE);
            }
            decThreadLocal.set(cipher);
        }
        return cipher;
    }
}
