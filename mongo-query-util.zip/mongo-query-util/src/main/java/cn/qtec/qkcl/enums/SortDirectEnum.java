package cn.qtec.qkcl.enums;

/**
 * @author Created by zhangp on 2018/5/10
 */
public class SortDirectEnum {
    private static final String SORT_DIRECT_DESC = "desc";
    private static final String SORT_DIRECT_ASC = "asc";
}
