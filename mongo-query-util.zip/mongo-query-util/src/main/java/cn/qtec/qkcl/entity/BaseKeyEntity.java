package cn.qtec.qkcl.entity;

import org.springframework.data.annotation.Id;

/**
 *
 * @author Created by INM on 2017/5/8
 */
public class BaseKeyEntity {
    @Id
    protected String id;
    protected byte[] key;
    protected long timeout;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public byte[] getKey() {
        return key;
    }

    public void setKey(byte[] key) {
        this.key = key;
    }

    public long getTimeout() {
        return timeout;
    }

    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }
}
