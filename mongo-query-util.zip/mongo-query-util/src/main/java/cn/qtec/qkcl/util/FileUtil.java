package cn.qtec.qkcl.util;

import cn.qtec.qkcl.entity.QuantumKey;
import cn.qtec.qkcl.security.ISecurity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * @author Created by zhangp on 2018/5/10
 */
public class FileUtil {
    private static final String CURRENT_DIR = System.getProperty("user.dir");

    public static void writeKeysToFile(String fileName, List <QuantumKey> quantumKeys, ISecurity security, int sortType, String sortDirect) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDate = dateFormat.format(new Date());

        boolean isEncrypted = security == null;

        File file = new File(CURRENT_DIR, fileName);

        OutputStreamWriter writer = null;
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(file, false);
            writer = new OutputStreamWriter(fileOutputStream, "UTF-8");
            String sortTypeName = sortType == 0 ? "createTime" : "keyId";

            writer.append("**************************************************************************************************************************");
            writer.append("\n*\t Query quantumKey results for the node ID is ").
                    append(String.valueOf(quantumKeys.get(0).getNodeID())).
                    append("\n*\t The current time is ").append(currentDate).
                    append("\n*\t The sort result is ordered by ").append(sortTypeName).
                    append("\n*\t The sort direct is ").append(sortDirect).
                    append("\n*\t Total Key number is ").append(Integer.toString(quantumKeys.size()));
            if (isEncrypted) {
                writer.append("\n*\t The results key value has encrypted with AES/CBC/PKCS7PADDING!");
            } else {
                writer.append("\n*\t The results key value has decrypted!");
            }
            writer.append("\n**************************************************************************************************************************\n");

            for (QuantumKey key : quantumKeys) {
                String keyId = HexTools.byteArrayToHexString(key.getKeyID());

                byte[] encKeyValue = key.getKey();
                String finalKeyValue;
                if (isEncrypted) {
                    finalKeyValue = HexTools.byteArrayToHexString(encKeyValue);
                } else {
                    byte[] decKeyValue = security.decryption(encKeyValue);
                    finalKeyValue = HexTools.byteArrayToHexString(decKeyValue);
                }
                writer.append(keyId).append("\t");
                writer.append(finalKeyValue).append("\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
