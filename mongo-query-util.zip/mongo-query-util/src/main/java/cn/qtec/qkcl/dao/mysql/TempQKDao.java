package cn.qtec.qkcl.dao.mysql;

import cn.qtec.qkcl.entity.QuantumKey;

import java.util.List;

/**
 * @author Created by zhangp on 2018/5/18
 */
public interface TempQKDao {
    void batchInsert(List <QuantumKey> list);

    List <QuantumKey> queryAllOrderByKeyId(String sortDirect);
}
