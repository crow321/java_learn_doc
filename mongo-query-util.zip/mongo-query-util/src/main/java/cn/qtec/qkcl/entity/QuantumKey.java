package cn.qtec.qkcl.entity;

import cn.qtec.qkcl.util.HexTools;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.*;
import java.util.Comparator;

/**
 * @author Created by INM on 2017/4/7
 */
@Document(collection = "quantum_key")
@Entity
@Table(name = "temp_quantum_key",indexes = {@Index(name = "key_id_index",columnList = "key_id")})
public class QuantumKey {
    @Id
    @Transient
    private String id;
    @Transient
    private int keyState;
    @Transient
    private int vaild;
    @Transient
    private String usage;
    @Transient
    private long timeout;

    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long indexId;
    @Column(name = "key_id")
    private byte[] keyID;
    @Column(name = "key_value")
    private byte[] key;
    @Column(name = "create_time")
    private long createTime;
    @Column(name = "node_id")
    private long nodeID;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public byte[] getKey() {
        return key;
    }

    public void setKey(byte[] key) {
        this.key = key;
    }

    public long getTimeout() {
        return timeout;
    }

    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }

    public byte[] getKeyID() {
        return keyID;
    }

    public void setKeyID(byte[] keyID) {
        this.keyID = keyID;
    }

    public long getNodeID() {
        return nodeID;
    }

    public void setNodeID(long nodeID) {
        this.nodeID = nodeID;
    }

    public int getKeyState() {
        return keyState;
    }

    public void setKeyState(int keyState) {
        this.keyState = keyState;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public int getVaild() {
        return vaild;
    }

    public void setVaild(int vaild) {
        this.vaild = vaild;
    }

    public String getUsage() {
        return usage;
    }

    public void setUsage(String usage) {
        this.usage = usage;
    }

    @Override
    public String toString() {
        return "QuantumKey{" +
                ", nodeID=" + nodeID +
                ", keyID=" + HexTools.byteArrayToHexString(keyID) +
                ", createTime=" + createTime +
                '}';
    }

}
