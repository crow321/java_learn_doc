package cn.qtec.qkcl.dao;

import cn.qtec.qkcl.entity.QuantumKey;
import java.util.List;

/**
 * @author Created by zhangp on 2018/5/10
 */
public interface QuantumKeyDao {
    long count(long nodeId);

    List <QuantumKey> queryByNodeId(long nodeId, int count);
}
