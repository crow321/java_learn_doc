package cn.qtec.qkcl.dao.mysql.impl;

import cn.qtec.qkcl.dao.mysql.TempQKDao;
import cn.qtec.qkcl.entity.QuantumKey;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Created by zhangp on 2018/5/18
 */
@Repository(value = "tempQKDao")
public class TempQKDaoImpl implements TempQKDao {
    private final SessionFactory sessionFactory;

    @Autowired
    public TempQKDaoImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void batchInsert(List <QuantumKey> list) {
        Session session = sessionFactory.getCurrentSession();

        for (int i = 0; i < list.size(); i++) {
            QuantumKey qk = list.get(i);
            session.save(qk);

            if (i > 0 && i % 20 == 0) {
                session.flush();
                session.clear();
            }
        }
        session.flush();
    }

    @Override
    public List <QuantumKey> queryAllOrderByKeyId(String sortDirect) {
        Session session = sessionFactory.getCurrentSession();
        String hqlOrderByKeyId = "from QuantumKey order by keyID " + sortDirect;
        Query query = session.createQuery(hqlOrderByKeyId);
        List list = query.list();
        return list != null && !list.isEmpty() ? list : null;
    }
}
