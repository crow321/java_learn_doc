package cn.qtec.qkcl.service.impl;

import cn.qtec.qkcl.dao.QuantumKeyDao;
import cn.qtec.qkcl.dao.mysql.TempQKDao;
import cn.qtec.qkcl.entity.QuantumKey;
import cn.qtec.qkcl.security.ISecurity;
import cn.qtec.qkcl.service.KeyQueryService;
import cn.qtec.qkcl.util.FileUtil;
import cn.qtec.qkcl.util.ListSortUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Created by zhangp on 2018/5/10
 */
@Service
public class KeyQueryServiceImpl implements KeyQueryService {
    private static final Logger logger = LoggerFactory.getLogger(KeyQueryServiceImpl.class);
    private static final String FILE_NAME_WITH_AES = "quantum_keys_aes.txt";
    private static final String FILE_NAME_WITHOUT_AES = "quantum_keys.txt";
    private final QuantumKeyDao quantumKeyDao;
    private final ISecurity security;
    private final TempQKDao qkDao;
    @Value("${sort.direct}")
    private String sortDirect;
    @Value("${query.node.id}")
    private long queryNodeId;
    @Value("${sort.type}")
    private int sortType;

    @Autowired
    public KeyQueryServiceImpl(QuantumKeyDao quantumKeyDao, ISecurity security, TempQKDao qkDao) {
        this.quantumKeyDao = quantumKeyDao;
        this.security = security;
        this.qkDao = qkDao;
    }

    @Override
    public List <QuantumKey> findAllByNodeIdByCreateTime() {
        List <QuantumKey> quantumKeys;
        if (sortType == 0) {
            quantumKeys = findAllByNodeIdByCreateTime(queryNodeId);
        } else {
            quantumKeys = findAllByNodeIdOrderByKeyId(queryNodeId);
        }

        writeToFile(quantumKeys, queryNodeId);
        return quantumKeys;
    }

    @Override
    public List <QuantumKey> findAllByNodeIdByCreateTime(long nodeId) {
        logger.info("Query node ID {} in mongoDb start ...", nodeId);
        List <QuantumKey> quantumKeys = quantumKeyDao.queryByNodeId(nodeId, Integer.MAX_VALUE);

        ListSortUtil <QuantumKey> sortUtil = new ListSortUtil <>();
        sortUtil.sort(quantumKeys, "createTime", sortDirect);

        logger.info("Query node ID {} in mongoDb end.", nodeId);
        return quantumKeys;
    }

    @Override
    public List <QuantumKey> findAllByNodeIdOrderByKeyId(long nodeId) {
        logger.info("Query node ID {} in mongoDb start ...", nodeId);
        List <QuantumKey> quantumKeys = quantumKeyDao.queryByNodeId(nodeId, Integer.MAX_VALUE);

        qkDao.batchInsert(quantumKeys);
        return qkDao.queryAllOrderByKeyId(sortDirect);
    }

    private void writeToFile(List <QuantumKey> quantumKeys, long nodeId) {
        if (quantumKeys != null && quantumKeys.size() > 0) {
            FileUtil.writeKeysToFile(FILE_NAME_WITH_AES, quantumKeys, null, sortType, sortDirect);
            FileUtil.writeKeysToFile(FILE_NAME_WITHOUT_AES, quantumKeys, security, sortType, sortDirect);
            logger.info("Write results complete .");
        } else {
            logger.error("Can't find any quantum keys for the node Id {}", nodeId);
        }
    }
}
