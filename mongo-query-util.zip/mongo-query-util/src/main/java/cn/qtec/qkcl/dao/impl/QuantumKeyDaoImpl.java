package cn.qtec.qkcl.dao.impl;

import cn.qtec.qkcl.dao.QuantumKeyDao;
import cn.qtec.qkcl.entity.QuantumKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Created by zhangp on 2018/5/10
 */
@Repository(value = "quantumKeyDao")
public class QuantumKeyDaoImpl implements QuantumKeyDao {
    private final MongoTemplate mongoTemplate;

    @Autowired
    public QuantumKeyDaoImpl(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }


    @Override
    public List <QuantumKey> queryByNodeId(long nodeId, int count) {
        Query query = new Query();
        Criteria criteria = Criteria.where("nodeID").is(nodeId);
        query.addCriteria(criteria);
        query.limit(count);
        return mongoTemplate.find(query, QuantumKey.class);
    }

    @Override
    public long count(long nodeId) {
        Query query = new Query();
        Criteria criteria = Criteria.where("nodeID").is(nodeId);
        query.addCriteria(criteria);
        return mongoTemplate.count(query, QuantumKey.class);
    }
}
