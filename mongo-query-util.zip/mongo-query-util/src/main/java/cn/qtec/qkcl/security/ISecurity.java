package cn.qtec.qkcl.security;

/**
 *
 * @author Created by INM on 2017/4/24
 */
public interface ISecurity {
    byte[] encryption(byte[] bytes) throws Exception;

    byte[] encryption(byte[] bytes, byte[] key) throws Exception;

    byte[] decryption(byte[] bytes) throws Exception;

    byte[] decryption(byte[] bytes, byte[] key) throws Exception;
}
